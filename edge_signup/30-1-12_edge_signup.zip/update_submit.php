<?php

require_once ('mysql_connection.php');


//echo print_r($_POST)."</br>";

$swipe_id = $_POST["swipe"];
$name = $_POST["name"];

$update_sql = "UPDATE edge_users SET name = '".$name."' WHERE swipe_id = ".$swipe_id;
$interest_del_sql = "DELETE FROM interest_table WHERE swipe_id = " . $swipe_id ;
$expertise_del_sql = "DELETE FROM expertise_table WHERE swipe_id = " . $swipe_id ;

$interest_sql = "INSERT INTO interest_table VALUES ";
$expertise_sql = "INSERT INTO expertise_table VALUES ";


foreach ($_POST as $name => $value) {	
	//echo $name . " = " . $value ;
	if(substr($name, 0, 1) === "i" && $value != "")
		$interest_sql = $interest_sql . "(".$swipe_id.",'".$value."'),";
	else if (substr($name, 0, 1) === "e" && $value != "")
		//echo "LOL";
		$expertise_sql = $expertise_sql . "(".$swipe_id.",'".$value."'),";	
	//echo "</br>";
}

$interest_sql = substr($interest_sql,0,strlen($interest_sql)-1);
$expertise_sql = substr($expertise_sql,0,strlen($expertise_sql)-1);

/*echo $interest_del_sql;
echo "</br>";
echo $expertise_del_sql;
echo "</br>";
echo $interest_sql;
echo "</br>";
echo $expertise_sql;*/

$sql = $update_sql . "; " . $interest_del_sql . "; " .$expertise_del_sql."; ".$interest_sql."; ".$expertise_sql."; ";
//echo $sql;


/*/echo $query;
$result = @mysql_query ($sql) or die(mysql_error());

if ($result ^= '1') 
	echo "There has been an error: " . mysql_error();
else 
	echo "Signed Up";*/
	
	$queries = preg_split("/;+(?=([^'|^\\\']*['|\\\'][^'|^\\\']*['|\\\'])*[^'|^\\\']*[^'|^\\\']$)/", $sql); 
foreach ($queries as $query){ 
   if (strlen(trim($query)) > 0) mysql_query($query) or die(mysql_error()); 
} 

echo "Profile Updated";

?>